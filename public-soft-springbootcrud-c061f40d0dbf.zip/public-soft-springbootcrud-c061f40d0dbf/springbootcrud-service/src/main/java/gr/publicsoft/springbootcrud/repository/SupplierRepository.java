package gr.publicsoft.springbootcrud.repository;
import gr.publicsoft.springbootcrud.model.Person;
import gr.publicsoft.springbootcrud.model.Supplier;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import gr.publicsoft.springbootcrud.model.Supplier;
import org.springframework.data.repository.query.Param;

import java.util.ArrayList;
import java.util.List;

public interface SupplierRepository extends CrudRepository<Supplier,Integer> {

    @Query("SELECT s FROM Supplier s "
            + "WHERE s.companyName LIKE CONCAT('%',?1,'%') ")
        Supplier findByCompanyName(@Param("query") String query);

    @Query("SELECT s FROM Supplier s "
            + "WHERE s.vatNumber LIKE CONCAT('%',?1,'%') ")
    Supplier findByVatNumber(@Param("query") String query);






}
