package gr.publicsoft.springbootcrud.service;
import java.util.ArrayList;
import java.util.List;

import gr.publicsoft.springbootcrud.repository.SupplierRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import gr.publicsoft.springbootcrud.model.Supplier;


@Service
public class SupplierService
{
    @Autowired
    SupplierRepository supplierRepository;
    public List<Supplier> getAllSuppliers()
    {
        List<Supplier> suppliers = new ArrayList<Supplier>();
        supplierRepository.findAll().forEach(supplier1 -> suppliers.add( supplier1));
        return suppliers;
    }

    public Supplier getSuppliersById(int id)
    {
        return supplierRepository.findById(id).get();
    }
    public String getSupplierByCompanyName(String name){
        return supplierRepository.findByCompanyName(name).getCompanyName();
    }
    public String getSupplierByVatNumber(String number){
        return supplierRepository.findByVatNumber(number).getVatNumber();
    }

    public void saveOrUpdate(Supplier supplier)
    {
        supplierRepository.save(supplier);
    }

    public void delete(int id)
    {
        supplierRepository.deleteById(id);
    }
    //updating a record
    public void update(Supplier supplier, int supplierid)
    {
        supplierRepository.save(supplier);
    }
}
