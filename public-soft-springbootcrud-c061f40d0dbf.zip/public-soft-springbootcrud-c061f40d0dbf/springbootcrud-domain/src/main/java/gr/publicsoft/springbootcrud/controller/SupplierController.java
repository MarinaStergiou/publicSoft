package gr.publicsoft.springbootcrud.controller;
import gr.publicsoft.springbootcrud.service.SupplierService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@RestController
public class SupplierController {
    @Autowired
    SupplierService supplierService;

    @GetMapping("/supplier")
    private List<gr.publicsoft.springbootcrud.model.Supplier> getAllSuppliers(){
    return supplierService.getAllSuppliers();  }

    @GetMapping("/supplier/{supplierid}")
    private gr.publicsoft.springbootcrud.model.Supplier getSuppliers(@PathVariable("supplierid") int supplierid)
    {
        return supplierService.getSuppliersById(supplierid);
    }
    @GetMapping("/supplier/{supplierCompanyName}")
    private String getSupplierByCompanyName(@PathVariable("supplierCompanyName") String supplierCompanyName)
    {
        return supplierService.getSupplierByCompanyName(supplierCompanyName);
    }
    @GetMapping("/supplier/{supplierVatNumber}")
    private String getSupplierByVatNumber(@PathVariable("supplierVatNumber") String supplierVatNumber)
    {
        return supplierService.getSupplierByVatNumber(supplierVatNumber);
    }


    @DeleteMapping("/supplier/{supplierid}")
    private void deleteSupplier(@PathVariable("supplierid") int supplierid)
    {
        supplierService.delete(supplierid);
    }

    @PostMapping("/supplier")
    private int saveSupplier(@RequestBody gr.publicsoft.springbootcrud.model.Supplier supplier)
    {
        supplierService.saveOrUpdate(supplier);
        return (int) supplier.getId();
    }

    @PutMapping("/supplier")
    private gr.publicsoft.springbootcrud.model.Supplier update(@RequestBody gr.publicsoft.springbootcrud.model.Supplier supplier)
    {
        supplierService.saveOrUpdate(supplier);
        return supplier;
    }

}
