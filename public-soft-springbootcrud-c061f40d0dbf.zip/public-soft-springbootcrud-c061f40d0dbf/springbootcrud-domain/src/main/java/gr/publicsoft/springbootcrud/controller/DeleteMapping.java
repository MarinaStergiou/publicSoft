package gr.publicsoft.springbootcrud.controller;

public @interface DeleteMapping {
}
