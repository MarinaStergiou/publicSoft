export default {
  sizes: {
    SIZE_XXS: 10,
    SIZE_XS: 20,
    SIZE_S: 50,
    SIZE_M: 100,
    SIZE_L: 255,
    SIZE_XL: 1000
  }
}
