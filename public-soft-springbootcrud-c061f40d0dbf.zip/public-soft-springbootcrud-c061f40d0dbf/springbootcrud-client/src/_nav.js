export default {
  items: [
    {
      name: 'HelloWorld',
      url: '/HelloWorld',
      icon: 'icon-calendar'
    },
    {
      name: 'Persons',
      url: '/persons',
      icon: 'icon-calendar'
    }
  ]
}
